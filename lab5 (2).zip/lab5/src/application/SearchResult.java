package application;

import java.util.List;

public class SearchResult {
	public List<Movie> Search; 
	
	public List<Movie> getSearch(){
		return Search;
	}
	
	public void setSearch(List<Movie> search){
		this.Search = search;
	}
}
